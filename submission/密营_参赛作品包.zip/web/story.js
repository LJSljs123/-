window.__MIYING_STORY__ = {
 "_note": "由 src/build_story.py 从 story_claims.json 生成，勿手工编辑。",
 "source": {
  "id": "src_wlt_hlj_beifuchang",
  "org": "黑龙江省文化和旅游厅（转载《黑龙江日报》）",
  "title": "抗联三军被服厂密营 密林深处的供给基地",
  "url": "https://wlt.hlj.gov.cn/wlt/c114274/202508/c00_31866464.shtml",
  "published": "2025-08-19",
  "type": "二手报道",
  "archive": "data/probe_archive/story_beifuchang__wlt-hlj.html"
 },
 "chapters": [
  {
   "no": 1,
   "title": "一件棉衣从哪里来",
   "date": "1936 年 8 月",
   "body": "1936 年 8 月，第三军为解决物资补给，在小西林河上游密林建立被服厂。故事从一件军衣的来处开始。",
   "duration": 10,
   "camera": [
    0.16,
    0.85,
    5.8,
    -1.8,
    2.35,
    0.1
   ],
   "claims": [
    {
     "id": "c1_1",
     "text": "1936 年 8 月，抗联三军决定在小西林河上游密林深处的老道庙沟、娘娘宫一线建立被服厂",
     "quote": "1936年8月，为解决抗联部队的物资补给问题，抗联三军决定在小西林河上游密林深处的老道庙沟、娘娘宫一线建立被服厂。",
     "boundary": "记载"
    }
   ],
   "visual": "院落与林木为合成场景。报道只说「一处小小的院落、几间简陋的木刻楞房屋」，具体间数、朝向与院落布局无记载，画面不据此断言。",
   "scene": {
    "workers": false,
    "props": false,
    "hands": false,
    "cloth": false,
    "coat": true,
    "cabins": false,
    "workbench": false,
    "machine": false,
    "lamp": false,
    "note": "以一件衣物剪影开场；场景为视觉引子，不代表实物留存"
   }
  },
  {
   "no": 2,
   "title": "三个人名，十三双手",
   "date": "1936 年 8 月",
   "body": "十五名成员里有十三位女工，其中十一位朝鲜族。金伯文任书记、陈静山任厂长；负责裁剪的“小把头”，先以称呼记下。",
   "duration": 12,
   "camera": [
    0.1,
    0.78,
    6.0,
    0.55,
    0.2,
    1.4
   ],
   "claims": [
    {
     "id": "c2_1",
     "text": "被服厂由 15 人组成；除阎把头和「小把头」为男同志外，其余 13 人为女同志，其中 11 人是朝鲜族",
     "quote": "抗联三军被服厂由15人组成，除阎把头和负责裁剪的“小把头”是男同志，其余13人均为女同志，其中11人是朝鲜族。",
     "boundary": "记载"
    },
    {
     "id": "c2_2",
     "text": "金伯文任党支部书记，陈静山任厂长，成员多从通河调来",
     "quote": "年轻的共产党员金伯文担任党支部书记，陈静山任厂长，成员多从通河调来。",
     "boundary": "记载"
    }
   ],
   "visual": "四组前臂与手是群像示意，不对应具体人物，也不按比例再现 15 人全体；衣着剪裁与相貌无记载，属设计。",
   "scene": {
    "workers": false,
    "props": false,
    "hands": true,
    "cloth": true,
    "machine": false,
    "lamp": true,
    "foreground": true,
    "note": "手的群像不按人数比例复原"
   }
  },
  {
   "no": 3,
   "title": "唯一一台旧机器",
   "date": "1936 年 8 月",
   "body": "全厂只有一台旧日本缝纫机；单衣与棉衣基本靠手工缝制。镜头停在针杆、压脚与布面的接触处。",
   "duration": 10,
   "camera": [
    0.1,
    0.78,
    3.2,
    1.0,
    0.05,
    1.58
   ],
   "claims": [
    {
     "id": "c3_1",
     "text": "被服厂只有一台旧日本缝纫机；单衣、棉衣基本以手工缝制为主",
     "quote": "由于物资匮乏，被服厂只有一台旧日本缝纫机，女战士们为抗联将士们制作的单衣、棉衣基本以手工缝制为主",
     "boundary": "记载"
    }
   ],
   "visual": "缝纫机形制为设计选型——原文只记「旧日本缝纫机」，未记型号；近景只保证「针杆、手、布」三者的接触关系可信。",
   "scene": {
    "workers": false,
    "props": false,
    "hands": false,
    "cloth": false,
    "machine": true,
    "macro": true,
    "lamp": true,
    "foreground": true,
    "note": "机器与手工：近景看针杆与手"
   }
  },
  {
   "no": 4,
   "title": "树皮熬出的颜色",
   "date": "1936 年 8 月",
   "body": "衣料多为白花其布。女战士以黄菠萝树皮、柞树皮熬水，将白布染成山林黄绿，用于伪装。",
   "duration": 11,
   "camera": [
    0.42,
    1.36,
    4.2,
    0.85,
    -0.15,
    1.62
   ],
   "claims": [
    {
     "id": "c4_1",
     "text": "制作衣服的原料靠缴获战利品，衣料多为白花其布",
     "quote": "而制作衣服的原料则是靠缴获敌人战利品，衣料多为白花其布。",
     "boundary": "记载"
    },
    {
     "id": "c4_2",
     "text": "用黄菠萝树皮和柞树皮熬水作染料，将白布染成与山林景色相近的黄绿色",
     "quote": "为便于战士们在山林中伪装杀敌，抗联女战士们就地取材，用黄菠萝树皮和柞树皮熬水作染料，将白布染成与山林景色相近的黄绿色，制成军衣。",
     "boundary": "记载"
    }
   ],
   "visual": "史料记为黄绿色；为遵守木刻舞台的单色规范，场景以明暗表现染布变化，不复原染液实色。染锅、蒸汽与摆位均为设计。",
   "scene": {
    "workers": false,
    "props": false,
    "hands": false,
    "cloth": false,
    "steam": true,
    "kettle": true,
    "machine": false,
    "lamp": true,
    "note": "染布工序"
   }
  },
  {
   "no": 5,
   "title": "同一张桌子，换了一件事",
   "date": "1936 年 9 月 18 日",
   "body": "联席会议在密营召开三天，选举成立中共北满临时省委。镜头从布料移向纸笔：这处密营也承载了组织工作。",
   "duration": 10,
   "camera": [
    0.12,
    0.95,
    3.8,
    -0.55,
    0.0,
    1.52
   ],
   "claims": [
    {
     "id": "c5_1",
     "text": "1936 年 9 月 18 日，联席会议在被服厂密营召开，历时 3 天，选举成立中共北满临时省委，15 人当选执行委员会委员",
     "quote": "9月18日，联席会议在抗联三军被服厂密营召开。此次会议历时3天，选举成立了中共北满临时省委，赵尚志、冯仲云、李兆麟等15人当选执行委员会委员。",
     "boundary": "记载"
    }
   ],
   "visual": "会议陈设、座次、发言均无记载，画面不重建会议现场，只用镜头停留表示「此处发生过组织工作」。",
   "scene": {
    "workers": false,
    "props": false,
    "hands": false,
    "cloth": false,
    "documents": true,
    "cabins": false,
    "machine": false,
    "lamp": false,
    "note": "纸笔是叙事道具；会场、座次与发言不作复原"
   }
  },
  {
   "no": 6,
   "title": "报信与转移：阎把头、陈静山",
   "date": "1937 年 4 月",
   "body": "阎把头把告密消息告知陈静山；陈静山率人员连夜转移，物资运往张木营子。镜头不补画队形与路线。",
   "duration": 11,
   "camera": [
    0.18,
    1.3,
    6.4,
    0.45,
    2.8,
    0.45
   ],
   "claims": [
    {
     "id": "c6_1",
     "text": "1937 年 4 月，被服厂被「老白党」发现并告密；阎把头告知陈静山，陈静山率人员连夜转移，物资运至张木营子抗联密营",
     "quote": "1937年4月，抗联三军被服厂被反动组织“老白党”发现并告密。危急时刻，阎把头迅速将消息告知厂长陈静山。陈静山率领人员连夜转移，将物资安全运至张木营子抗联密营",
     "boundary": "记载"
    }
   ],
   "visual": "脚印只是转移的视觉符号，不表示史料所载路线或队形；已转移人员与物资移出画面，留守者不作具象重建。",
   "scene": {
    "workers": false,
    "props": false,
    "hands": false,
    "cloth": false,
    "transfer": true,
    "machine": false,
    "lamp": false,
    "foreground": true,
    "note": "以抽象脚印表现转移，不还原具体路线"
   }
  },
  {
   "no": 7,
   "title": "小把头未能及时撤离",
   "date": "1937 年 4 月",
   "body": "记载说，负责裁剪的“小把头”未能及时撤离，当晚遇袭牺牲；四间木刻楞房屋被焚毁。随后留出三秒空白。",
   "duration": 14,
   "camera": [
    0.32,
    1.28,
    6.0,
    0.0,
    0.2,
    1.12
   ],
   "claims": [
    {
     "id": "c7_1",
     "text": "留守的「小把头」因未能及时撤离，当晚遭敌人袭击牺牲，4 间木刻楞房屋被焚毁",
     "quote": "然而，留守的“小把头”因未能及时撤离，当晚遭到敌人袭击，不幸壮烈牺牲，4间木刻楞房屋也被付之一炬。",
     "boundary": "记载"
    }
   ],
   "visual": "空台是叙事停顿，不断言当夜实景；人物、布料、机器、茶壶与灯台均不入画。不出现搏斗、遗体或遗言——原文未记，画面不补。",
   "scene": {
    "workers": false,
    "props": false,
    "hands": false,
    "cloth": false,
    "empty": true,
    "cabins": false,
    "lightPatch": true,
    "machine": false,
    "kettle": false,
    "lamp": false,
    "note": "无人、无可见道具的三秒停顿；不复原历史现场"
   }
  },
  {
   "no": 8,
   "title": "遗址与三种记载",
   "date": "遗址保护与再建",
   "body": "2006 年列为伊春市级文保单位，2013 年原址复建。再看三条日期记载：支持分布可见，结论仍留在证据边界内。",
   "duration": 10,
   "camera": [
    -0.26,
    1.3,
    19,
    0.2,
    -3.4,
    2.05
   ],
   "claims": [
    {
     "id": "c8_1",
     "text": "2006 年遗址被伊春市政府确定为市级文物保护单位；2013 年西林区政府在遗址原地按原貌复建",
     "quote": "2006年，抗联三军被服厂密营遗址被伊春市政府确定为市级文物保护单位。2013年西林区政府在遗址原地按原貌进行复建",
     "boundary": "记载"
    }
   ],
   "visual": "院落为程序化合成，不是遗址扫描；三条日期属于童长荣牺牲日期案 KL-012，与被服厂事件分开呈现，不暗示两事有关。",
   "scene": {
    "workers": false,
    "props": false,
    "hands": false,
    "cloth": false,
    "machine": false,
    "kettle": false,
    "lamp": false,
    "note": "以数字复建示意收尾，并转入独立的日期分歧案"
   }
  }
 ],
 "stats": {
  "chapters": 8,
  "claims": 10,
  "duration_seconds": 88
 }
};
